# Revisor Nómina CFE 2026

Aplicación Android offline para estimar y revisar una catorcena de personal CFE usando exclusivamente el tabulador diario **agosto 2026** proporcionado para los puestos MANTO, OPERA y ADMIN.

## Incluye
- Selección de puesto base y puesto cubierto.
- Diferencia salarial por número de días cubiertos.
- Prestaciones CCT 2026-2028: renta 52.20%, despensa 41.06%, transporte 41.00%.
- Tiempo extraordinario doble/triple como referencia de LFT.
- Exención estimada de horas extra e ISR 2026 con tarifa semanal SAT.
- Fondo de ahorro: trabajador configurable (6.5% por defecto) y CFE 35%.
- Fondo de previsión 13.50%.
- Comparación rápida contra neto e ISR del recibo.
- Funciona sin internet y guarda los últimos datos sólo en el teléfono.

## Importante sobre centavos
El tabulador de agosto 2026 está expresado a centavos por día. Una nómina CFE puede distribuir algunos centavos de forma distinta entre las líneas `Salario` y `Diferencia de salario` por redondeos internos. Para una cobertura conviene comparar primero `Salario + Diferencia`.

## Construir APK con GitHub Actions
1. Sube esta carpeta a un repositorio de GitHub.
2. Entra a **Actions > Build APK**.
3. Ejecuta **Run workflow** o haz un push a `main`.
4. Descarga el artefacto **Revisor-Nomina-CFE-2026**.
5. El archivo `Revisor-Nomina-CFE-2026.apk` es instalable y se puede compartir por WhatsApp.

El workflow genera un APK `debug` firmado automáticamente por Android, adecuado para instalación directa y pruebas internas. Para publicar en Google Play conviene crear una firma de release propia.

## Alcance fiscal
La tarifa SAT es 2026. Si el usuario captura la **base gravada del CFDI**, el cálculo del ISR parte de ese importe. Si no la captura, la app usa un modelo estimado de tratamiento gravado/exento de prestaciones CFE calibrado con recibos reales. No sustituye CFDI, CCT ni una revisión formal de nómina.


## Cambios v1.1
- Modo **Permanente / titular** y **Temporal de sustitución**.
- El temporal puede dividir una catorcena entre varias plazas y la app suma puesto × días.
- Historial anual local de coberturas con promedio diario ponderado por días pagados.
- Fórmula contractual CFE para tiempo extraordinario: salario diario × 6 / 40; 1–9 horas dobles y 10+ triples por semana.
- Soporte inicial para turnos continuos: TEC manual, compensación por jornada nocturna estimada, prima dominical, festivos y coincidencias con descanso semanal.
- Sólo se usa el tabulador de agosto de 2026 proporcionado por el usuario.

### Pendiente para afinar Operación
Se requiere al menos una papeleta/recibo de un puesto de operación para identificar el importe exacto del Tiempo Extra Constante y validar códigos de compensación nocturna, festivos y descansos.
